package it.unitn.http;

import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngineDescription;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.uima.analysis_engine.AnalysisEngineDescription;
import org.apache.uima.cas.CAS;
import org.apache.uima.fit.factory.TypeSystemDescriptionFactory;
import org.apache.uima.fit.pipeline.SimplePipeline;
import org.apache.uima.json.JsonCasSerializer;
import org.apache.uima.util.CasCreationUtils;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.StanfordNamedEntityRecognizer;
import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.StanfordParser;
import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.StanfordSegmenter;
import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.StanfordPosTagger;
import it.unitn.anlp.MovieAnnotator;
import it.unitn.anlp.Utilities;

public class Handlers {
	
	private AnalysisEngineDescription seg = null;
	private AnalysisEngineDescription pos = null;
	private AnalysisEngineDescription movie = null;
	private AnalysisEngineDescription ner = null;
	private CAS cas = null;
	private JsonCasSerializer jsonCasSerializer = null;
	public Handlers() {
		try {
			seg = createEngineDescription(StanfordSegmenter.class);
			pos = createEngineDescription(StanfordPosTagger.class);
			movie = createEngineDescription(MovieAnnotator.class);
			ner = createEngineDescription(StanfordNamedEntityRecognizer.class,
																	StanfordNamedEntityRecognizer.PARAM_VARIANT,
																	"muc.7class.distsim.crf");
			cas = CasCreationUtils.createCas(TypeSystemDescriptionFactory.createTypeSystemDescription(), null, null);
			jsonCasSerializer = new JsonCasSerializer();
		} catch (Exception e) {
		}
	}
	
	public static class EchoIndexHandler implements HttpHandler {
		public void handle(HttpExchange he) throws IOException {
			String response = new Utilities().readFromAFile("files/htmls/index.html");
			he.sendResponseHeaders(200, response.length());
			OutputStream os = he.getResponseBody();
			os.write(response.getBytes());
			os.close();
		}
	}

	public static class IndexHandler implements HttpHandler {
		public void handle(HttpExchange he) throws IOException {
			Map<String, Object> parameters = new HashMap<String, Object>();
			InputStreamReader isr = new InputStreamReader(he.getRequestBody(), "utf-8");
			BufferedReader br = new BufferedReader(isr);
			String query = br.readLine();
			new Handlers().parseQuery(query, parameters);
			String content = "";
			for (String key : parameters.keySet()) {
				if (key.equals("content"))
					content = parameters.get(key).toString();
			}
			he.getResponseHeaders().add("Content-type", "text/plain");
			he.sendResponseHeaders(200, 0);
			OutputStream os = he.getResponseBody();
			new Handlers().process(content, os);
		}
	}

	public void process(String content, OutputStream os) {
		try {
			cas.reset();
			cas.setDocumentText(content);
			cas.setDocumentLanguage("en");
			SimplePipeline.runPipeline(cas, seg, pos, ner, movie);
			try {
				jsonCasSerializer.jsonSerialize(cas, os);
				os.close();
			} catch (Exception e) {
				os.close();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void parseQuery(String query, Map<String, Object> parameters) throws UnsupportedEncodingException {
		if (query != null) {
			String pairs[] = query.split("[&]");
			for (String pair : pairs) {
				String param[] = pair.split("[=]");
				String key = null;
				String value = null;
				if (param.length > 0) {
					key = URLDecoder.decode(param[0], System.getProperty("file.encoding"));
				}
				if (param.length > 1) {
					value = URLDecoder.decode(param[1], System.getProperty("file.encoding"));
				}
				if (parameters.containsKey(key)) {
					Object obj = parameters.get(key);
					if (obj instanceof List<?>) {
						List<String> values = (List<String>) obj;
						values.add(value);
					} else if (obj instanceof String) {
						List<String> values = new ArrayList<String>();
						values.add((String) obj);
						values.add(value);
						parameters.put(key, values);
					}
				} else {
					parameters.put(key, value);
				}
			}
		}
	}
}
