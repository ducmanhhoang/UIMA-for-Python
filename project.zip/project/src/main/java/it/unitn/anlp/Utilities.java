package it.unitn.anlp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class Utilities {

	public String readFromAFile(String uri) {
		String st = "";
		try {
			BufferedReader br = new BufferedReader(new FileReader(uri));
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();
			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			st = sb.toString();
			br.close();
		} catch (Exception e) {
			System.err.println(e);
		}
		return st;
	}

}
