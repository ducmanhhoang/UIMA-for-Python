package it.unitn.anlp;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;
import org.apache.uima.json.JsonCasSerializer;
import org.apache.uima.resource.ResourceInitializationException;

import de.tudarmstadt.ukp.dkpro.core.api.lexmorph.type.pos.POS;
import de.tudarmstadt.ukp.dkpro.core.api.ner.type.NamedEntity;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.tudarmstadt.ukp.dkpro.core.api.syntax.type.constituent.NP;
import it.unitn.types.Actor;
import it.unitn.types.Cinematographer;
import it.unitn.types.Director;
import it.unitn.types.Screenwriter;


public class MovieAnnotator extends JCasAnnotator_ImplBase {

	List<Pattern> directorPatterns;
	List<Pattern> actorPatterns;
	List<Pattern> screenwriterPatterns;
	List<Pattern> cinematographerPatterns;
	JsonCasSerializer jsonCasSerializer = new JsonCasSerializer();

	@Override
	public void initialize(UimaContext aContext) throws ResourceInitializationException {
		// TODO Auto-generated method stub
		super.initialize(aContext);
		String[] directorPatternStrings = {"(directed/VBN by/IN )((([A-z]*)/NNP )+)",
				"(((directed/JJ by/IN )((([A-z]*)/NNP )+))|(((directed/JJ) ,/, )((((([A-z]*)/JJ ),/, )|((([A-z]*-[A-z]*)/JJ ),/, ))+)(and/CC )((((([A-z]*)/JJ ),/, )|((([A-z]*-[A-z]*)/JJ )))+)(by/IN )((([A-z]*)/NNP )+)))"};
		this.directorPatterns = new ArrayList<Pattern>();
		for (String directorPatternString : directorPatternStrings) {
			this.directorPatterns.add(Pattern.compile(directorPatternString));
		}
		String[] actorPatternStrings = {"(stars/VBZ )((([A-z]*)/NNP )+)",
				"(stars/VBZ )(((([A-z]*)/NNP )+,/, )+)(and/CC )((([A-z]*)/NNP )+)",
				"(([A-z]*/NNP )+)(plays/VBZ )((a|an)/DT )(([A-z]*/JJ )|([A-z]*/NN ))",
				"(played/VBN by/IN )(([A-z]*)/NNP )",
				"(stars/VBZ )((([A-z]*)/NNP )+)(and/CC )((([A-z]*)/NNP )+)"};
		this.actorPatterns = new ArrayList<Pattern>();
		for (String actorPatternString : actorPatternStrings) {
			this.actorPatterns.add(Pattern.compile(actorPatternString));
		}
		String[] screenwriterPatternStrings = {"screenwriter[s]?/NN[S]? ([A-z]*)/(?:NN[S]?|JJ) ([A-z]*)/(?:NN|JJ)",
				"(((written/JJ by/IN )((([A-z]*)/NNP )+))|(((written/JJ) ,/, )((((([A-z]*)/JJ ),/, )|((([A-z]*-[A-z]*)/JJ ),/, ))+)(and/CC )((((([A-z]*)/JJ ),/, )|((([A-z]*-[A-z]*)/JJ )))+)(by/IN )((([A-z]*)/NNP )+)))"};
		this.screenwriterPatterns = new ArrayList<Pattern>();
		for (String screenwriterPatternString : screenwriterPatternStrings) {
			this.screenwriterPatterns.add(Pattern.compile(screenwriterPatternString));
		}
		String[] cinematographerPatternStrings = {"cinematographer/NN(?: ,/,)? ([A-z]*)/NN ([A-z]*)/NN",
				"cinematographer/NN(?: ,/,)? ([A-z]*)/NN ([A-z]*)/IN ([A-z]*)/NN"};
		this.cinematographerPatterns = new ArrayList<Pattern>();
		for (String cinematographerPatternString : cinematographerPatternStrings) {
			this.cinematographerPatterns.add(Pattern.compile(cinematographerPatternString));
		}

	}

	@Override
	public void process(JCas arg0) throws AnalysisEngineProcessException {
		ArrayList<Integer> eIndex = new ArrayList<Integer>();
		for (Sentence sentence : JCasUtil.select(arg0, Sentence.class)) {
			for (NamedEntity ne : JCasUtil.selectCovered(arg0, NamedEntity.class, sentence)) {
				boolean save = true;
				if (eIndex.size() != 0) {
					for (int index : eIndex) {
						if (ne.getBegin() == index) {
							save = false;
						}
					}
				}
				if (ne.getType().toString().equals("de.tudarmstadt.ukp.dkpro.core.api.ner.type.Person") && save) {
					String namePos = "";
					for (Token token : JCasUtil.selectCovered(arg0, Token.class, ne)) {
						namePos = token.getCoveredText() + "/" + token.getPos().getPosValue() + " ";
					}
					String posedSentence = "";
					for (POS pos : JCasUtil.selectCovered(arg0, POS.class, sentence)) {
						posedSentence = posedSentence + pos.getCoveredText() + "/" + pos.getPosValue() + " ";
					}
					//System.out.println(posedSentence);

					if (save(arg0, ne, posedSentence, namePos, this.directorPatterns, "Director")) {
						eIndex.add(ne.getBegin());
					}
					if (save(arg0, ne, posedSentence, namePos, this.actorPatterns, "Actor")) {
						eIndex.add(ne.getBegin());
					}
					if (save(arg0, ne, posedSentence, namePos, this.screenwriterPatterns, "Screenwriter")) {
						eIndex.add(ne.getBegin());
					}
					if (save(arg0, ne, posedSentence, namePos, this.cinematographerPatterns, "Cinematographer")) {
						eIndex.add(ne.getBegin());
					}
				}

			}

		}

	}
	
	public boolean save(JCas arg0, NamedEntity ne, String posedSentence, String namePos, List<Pattern> patterns, String type) {
		boolean save = false;
		for (Pattern pattern : patterns) {
			Matcher matcher = pattern.matcher(posedSentence);
			String foundS = "";
			while (matcher.find()) {
				StringBuilder foundSB = new StringBuilder();

				for (int i = 1; i <= matcher.groupCount(); i++) {
					foundSB.append(matcher.group(i));
					if (i != matcher.groupCount()) {
						foundSB.append(" ");
					}
				}

				foundS = foundSB.toString();
			}
			if(foundS.contains(namePos)) {
				save = true;
			}
		}
		
		if(save) {
			if(type == "Director") {
				//System.out.println(ne.getCoveredText() + "Director" + ne.getBegin());
				Director director = new Director(arg0);
				director.setBegin(ne.getBegin());
				director.setEnd(ne.getEnd());
				director.setValue(ne.getCoveredText());
				director.addToIndexes(arg0);
			} else if(type == "Actor") {
				//System.out.println(ne.getCoveredText() + "Actor" + ne.getBegin());
				Actor actor = new Actor(arg0);
				actor.setBegin(ne.getBegin());
				actor.setEnd(ne.getEnd());
				actor.setValue(ne.getCoveredText());
				actor.addToIndexes(arg0);
			} else if(type == "Screenwriter") {
				//System.out.println(ne.getCoveredText() + "Screenwriter" + ne.getBegin());
				Screenwriter screenwriter = new Screenwriter(arg0);
				screenwriter.setBegin(ne.getBegin());
				screenwriter.setEnd(ne.getEnd());
				screenwriter.setValue(ne.getCoveredText());
				screenwriter.addToIndexes(arg0);
			} else if(type == "Cinematographer") {
				//System.out.println(ne.getCoveredText() + "Cinematographer" + ne.getBegin());
				Cinematographer cinematographer = new Cinematographer(arg0);
				cinematographer.setBegin(ne.getBegin());
				cinematographer.setEnd(ne.getEnd());
				cinematographer.setValue(ne.getCoveredText());
				cinematographer.addToIndexes(arg0);
			}
		}
		return save;
	}

}
