package it.unitn.anlp;

import it.unitn.http.SimpleHttpServer;
import it.unitn.http.Handlers;

public class App {
	public final static int port = 9000;
	public static void main(String[] args) {
		run_http_server();
	}

	public static void run_http_server() {
		// start http server
		SimpleHttpServer httpServer = new SimpleHttpServer();
		httpServer.Start(port);
	}

}
